let balance = 1000;

document.getElementById("bet-button").addEventListener("click", () => {
    let betAmount = parseFloat(document.getElementById("bet-amount").value);
    let slider = document.getElementById("risk-slider");
    let multiplier = parseInt(slider.value);
    
    if (betAmount <= 0 || betAmount > balance) {
        alert("Invalid bet amount!");
        return;
    }

    document.getElementById("click-sound").play();

    let winChance = 100 / multiplier;
    let roll = Math.random() * 100;
    let won = roll <= winChance;

    let history = document.getElementById("history");
    let resultDiv = document.createElement("div");
    resultDiv.classList.add("history-item");
    resultDiv.innerText = Math.floor(roll);

    if (won) {
        balance += betAmount * (multiplier - 1);
        resultDiv.classList.add("win");
        document.getElementById("win-sound").play();
    } else {
        balance -= betAmount;
        resultDiv.classList.add("lose");
        document.getElementById("lose-sound").play();
    }

    history.prepend(resultDiv);
    if (history.children.length > 8) history.removeChild(history.lastChild);
    
    document.getElementById("balance").innerText = balance;
});
